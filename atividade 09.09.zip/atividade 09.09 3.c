#include <stdio.h>

int main() {
    int num;

    printf("Digite um número inteiro: ");
    scanf("%d", &num);

    printf("Número digitado: %d. Sucessor: %d. Antecessor: %d\n", num, num + 1, num - 1);

    return 0;
}