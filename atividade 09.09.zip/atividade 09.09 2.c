#include <stdio.h>

int main() {
    float numA, numB, media;

    printf("Digite o primeiro número real: ");
    scanf("%f", &numA);

    printf("Digite o segundo número real: ");
    scanf("%f", &numB);

    media = (numA + numB) / 2;

    printf("A média entre %.1f e %.1f é %.1f\n", numA, numB, media);

    return 0;
}