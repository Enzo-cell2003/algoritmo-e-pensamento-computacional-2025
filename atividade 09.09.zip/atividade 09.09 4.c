#include <stdio.h>

int main() {
    int num, resultado;

    printf("Digite um número inteiro: ");
    scanf("%d", &num);

    resultado = num * num;

    printf("O número %d elevado a 2 é %d\n", num, resultado);

    return 0;
}