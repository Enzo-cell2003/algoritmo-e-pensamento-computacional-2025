//Exemplo atribuição automática
#include <stdio.h>
int main()
{
    int numA, numB, numC;
    printf ("Digite o 1º número: ");//Função de saida de dados
    scanf("%i",&numA); //Função de entrada de dados
    printf ("Digite o 2º número: ");
    scanf("%i",&numB);
    printf ("Digite o 3º número: ");
    scanf("%i",&numC);
    printf("%i + %i + %i = %i",numA, numB, numC, numA + numB + numC);
    return 0;
    
}